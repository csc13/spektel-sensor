/*
 * adc_sens.c
 *
 * Created: 13.10.2014 22:36:35
 *  Author: chris
 */ 
