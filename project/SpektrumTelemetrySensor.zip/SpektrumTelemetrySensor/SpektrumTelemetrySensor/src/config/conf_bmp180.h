/*
 * conf_bmp180.h
 *
 * Created: 03.01.2015 03:11:48
 *  Author: chris
 */ 


#ifndef CONF_BMP180_H_
#define CONF_BMP180_H_

#define BMP180_RESOLUTION BMP180_RES_ULTRAHIGH
#define BMP180_START_ALTITUDE 0

#endif /* CONF_BMP180_H_ */